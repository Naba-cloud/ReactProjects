import React from "react";
import Randombg from "./Randombg";
import "./styles.css";
class App extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    return <Randombg />;
  }
}
export default App;
